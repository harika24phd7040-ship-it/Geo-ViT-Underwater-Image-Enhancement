import torch
import torch.nn as nn


class ViTBlock(nn.Module):
    """Multi-head self-attention over spatial positions (conv 1x1 qkv/proj)."""

    def __init__(self, dim, heads=4):
        super().__init__()
        self.heads = heads
        self.norm = nn.LayerNorm(dim)
        self.qkv = nn.Conv2d(dim, dim * 3, 1)
        self.proj = nn.Conv2d(dim, dim, 1)

    def forward(self, x):
        b, c, h, w = x.shape
        shortcut = x

        x = x.permute(0, 2, 3, 1)
        x = self.norm(x)
        x = x.permute(0, 3, 1, 2)

        qkv = self.qkv(x).reshape(b, 3, self.heads, c // self.heads, h * w)
        q, k, v = qkv[:, 0], qkv[:, 1], qkv[:, 2]

        attn = (q.transpose(-2, -1) @ k) * (c ** -0.5)
        attn = attn.softmax(dim=-1)

        out = (v @ attn.transpose(-2, -1)).reshape(b, c, h, w)
        return shortcut + self.proj(out)
