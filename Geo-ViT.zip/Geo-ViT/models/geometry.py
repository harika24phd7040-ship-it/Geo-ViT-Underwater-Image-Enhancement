import torch
import torch.nn as nn
import torch.nn.functional as F


class GeometryEncoder(nn.Module):
    """Sobel edge-magnitude map of the grayscale input, projected to `out_ch` channels."""

    def __init__(self, out_ch):
        super().__init__()
        self.conv = nn.Conv2d(1, out_ch, 3, padding=1)

    def forward(self, x):
        gray = x.mean(1, keepdim=True)
        sobel_x = torch.tensor(
            [[1, 0, -1], [2, 0, -2], [1, 0, -1]],
            device=x.device,
            dtype=torch.float32,
        ).view(1, 1, 3, 3)
        sobel_y = sobel_x.transpose(2, 3)
        edge = torch.sqrt(
            F.conv2d(gray, sobel_x, padding=1) ** 2
            + F.conv2d(gray, sobel_y, padding=1) ** 2
            + 1e-6
        )
        return self.conv(edge)
