import torch
import torch.nn as nn
import torch.nn.functional as F


class MambaBlock(nn.Module):
    """Gated depth-wise convolutional block with a scaled residual connection.

    Note: this is a lightweight Mamba-inspired gated block (depth-wise conv +
    sigmoid gating); it does not implement a selective state-space scan.
    """

    def __init__(self, dim):
        super().__init__()
        self.dw = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
        self.pw = nn.Conv2d(dim, dim, 1)
        self.gate = nn.Conv2d(dim, dim, 1)
        self.norm = nn.BatchNorm2d(dim)

    def forward(self, x):
        res = x
        g = torch.sigmoid(self.gate(x))
        x = self.dw(x)
        x = self.norm(x)
        x = F.gelu(x)
        x = self.pw(x * g)
        return res + 0.2 * x
