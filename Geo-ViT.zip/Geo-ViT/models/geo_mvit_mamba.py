import torch
import torch.nn as nn
import torch.nn.functional as F

from .geometry import GeometryEncoder
from .mamba_block import MambaBlock
from .vit_block import ViTBlock


class GeoMViTMambaUNet(nn.Module):
    """Geo-MViT-Mamba v2: U-Net with geometry-guided stem and a hybrid
    Mamba-block / ViT-block bottleneck. Predicts a residual added to the input."""

    def __init__(self):
        super().__init__()

        self.geo = GeometryEncoder(64)

        # Encoder
        self.e1 = nn.Conv2d(3, 64, 3, padding=1)
        self.e2 = nn.Conv2d(64, 128, 4, stride=2, padding=1)
        self.e3 = nn.Conv2d(128, 256, 4, stride=2, padding=1)
        self.e4 = nn.Conv2d(256, 512, 4, stride=2, padding=1)

        # Bottleneck (6 hybrid blocks)
        self.b1 = MambaBlock(512)
        self.b2 = ViTBlock(512)
        self.b3 = MambaBlock(512)
        self.b4 = ViTBlock(512)
        self.b5 = MambaBlock(512)
        self.b6 = ViTBlock(512)

        # Decoder
        self.d1 = nn.ConvTranspose2d(512, 256, 2, stride=2)
        self.d2 = nn.ConvTranspose2d(256, 128, 2, stride=2)
        self.d3 = nn.ConvTranspose2d(128, 64, 2, stride=2)

        self.final = nn.Conv2d(64, 3, 3, padding=1)

    def forward(self, x):
        identity = x
        geo_feat = self.geo(x)

        e1 = F.gelu(self.e1(x) + geo_feat)
        e2 = F.gelu(self.e2(e1))
        e3 = F.gelu(self.e3(e2))
        e4 = F.gelu(self.e4(e3))

        b = self.b1(e4)
        b = self.b2(b)
        b = self.b3(b)
        b = self.b4(b)
        b = self.b5(b)
        b = self.b6(b)

        d1 = F.gelu(self.d1(b) + e3)
        d2 = F.gelu(self.d2(d1) + e2)
        d3 = F.gelu(self.d3(d2) + e1)

        out = self.final(d3)
        return torch.clamp(identity + out, 0, 1)
