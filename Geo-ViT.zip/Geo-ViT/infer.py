"""Enhance a single image or a folder of images.

Example:
    python infer.py --ckpt checkpoints/best_geomvitmamba_v2.pth --input my.jpg --output results/
"""
import argparse
import os

import torch
import torchvision.transforms as T
from PIL import Image
from torchvision.utils import save_image

from models import GeoMViTMambaUNet
from utils.dataset import IMG_EXTS


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--ckpt", required=True)
    p.add_argument("--input", required=True, help="image file or folder")
    p.add_argument("--output", default="results")
    p.add_argument("--img_size", type=int, default=256)
    args = p.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = GeoMViTMambaUNet().to(device)
    model.load_state_dict(torch.load(args.ckpt, map_location=device))
    model.eval()

    tf = T.Compose([T.Resize((args.img_size, args.img_size)), T.ToTensor()])
    os.makedirs(args.output, exist_ok=True)

    if os.path.isdir(args.input):
        files = [os.path.join(args.input, f) for f in sorted(os.listdir(args.input))
                 if f.lower().endswith(IMG_EXTS)]
    else:
        files = [args.input]

    with torch.no_grad():
        for f in files:
            x = tf(Image.open(f).convert("RGB")).unsqueeze(0).to(device)
            save_image(model(x), os.path.join(args.output, os.path.basename(f)))
            print("saved", os.path.basename(f))


if __name__ == "__main__":
    main()
