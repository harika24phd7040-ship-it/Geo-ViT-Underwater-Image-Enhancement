# Geo-MViT-Mamba: Underwater Image Enhancement

Official implementation of **"<PAPER TITLE>"**, published in *Scientific Reports* (<YEAR>).
Paper: <DOI link> | Code archive (Zenodo): <Zenodo DOI badge>

Geo-MViT-Mamba v2 is a U-Net style network for underwater image enhancement. A
Sobel-based geometry encoder is fused into the first encoder stage, and a
bottleneck of six alternating Mamba-style gated blocks and self-attention (ViT)
blocks models long-range context. The network predicts a residual that is added
to the input image.

## Repository structure

```
.
├── models/
│   ├── geometry.py          # GeometryEncoder (Sobel edge features)
│   ├── mamba_block.py       # MambaBlock (gated depth-wise conv block)
│   ├── vit_block.py         # ViTBlock (multi-head self-attention)
│   └── geo_mvit_mamba.py    # GeoMViTMambaUNet (full network)
├── utils/
│   ├── dataset.py           # UIEBDataset (paired loader)
│   ├── losses.py            # Charbonnier + VGG16 perceptual loss
│   ├── metrics.py           # PSNR, SSIM
│   └── seed.py
├── train.py                 # training
├── evaluate.py              # PSNR / SSIM on a paired folder
├── infer.py                 # enhance your own images
├── notebooks/               # original Kaggle notebook used for the experiments
├── checkpoints/             # put pretrained weights here
└── requirements.txt
```

## Installation

```bash
git clone https://github.com/<USERNAME>/<REPO>.git
cd <REPO>
pip install -r requirements.txt
```

## Dataset

We use the [UIEB dataset](https://li-chongyi.github.io/proj_benchmark.html)
(Li et al., 2019). Arrange it as:

```
UIEB/
├── trainA/  # degraded training images
├── trainB/  # reference training images
├── valA/    # degraded validation images
└── valB/    # reference validation images
```

Input and reference images must share the same file name. <DESCRIBE YOUR TRAIN/VAL SPLIT, e.g. "800 train / 90 val, random split with seed ...">

## Training

```bash
python train.py --data_root /path/to/UIEB
```

Default settings: image size 256x256, batch size 4, 200 epochs, AdamW (lr 2e-4,
cosine annealing), loss = Charbonnier + 0.1 x VGG16 perceptual loss.
The checkpoint with the best validation PSNR is saved to `checkpoints/`.

## Evaluation

```bash
python evaluate.py --ckpt checkpoints/best_geomvitmamba_v2.pth \
    --input_dir /path/to/UIEB/valA --gt_dir /path/to/UIEB/valB
```

## Inference

```bash
python infer.py --ckpt checkpoints/best_geomvitmamba_v2.pth \
    --input path/to/image_or_folder --output results/
```

## Pretrained weights

Download `best_geomvitmamba_v2.pth` from <Zenodo/Release link> and place it in `checkpoints/`.

## Results

Best validation PSNR in our training run (UIEB val, 256x256): 24.70 dB.
<REPLACE / EXTEND WITH THE EXACT NUMBERS FROM THE PAPER: PSNR, SSIM, UIQM, UCIQE, and any other benchmarks.>

## Notes

- `MambaBlock` is a lightweight Mamba-inspired gated depth-wise convolution block; it does not include a selective state-space scan.
- Images are resized to 256x256 for training and evaluation.

## Citation

```bibtex
@article{<key>,
  title   = {<PAPER TITLE>},
  author  = {<AUTHORS>},
  journal = {Scientific Reports},
  year    = {<YEAR>},
  doi     = {<DOI>}
}
```

## License

MIT License, see `LICENSE`.
