"""Train Geo-MViT-Mamba v2 on UIEB.

Example:
    python train.py --data_root /path/to/UIEB
Expected layout:  <data_root>/{trainA,trainB,valA,valB}
"""
import argparse
import os

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from models import GeoMViTMambaUNet
from utils.dataset import UIEBDataset
from utils.losses import TotalLoss
from utils.metrics import psnr
from utils.seed import set_seed


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data_root", required=True)
    p.add_argument("--img_size", type=int, default=256)
    p.add_argument("--batch_size", type=int, default=4)
    p.add_argument("--epochs", type=int, default=200)
    p.add_argument("--lr", type=float, default=2e-4)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--num_workers", type=int, default=2)
    p.add_argument("--out", default="checkpoints/best_geomvitmamba_v2.pth")
    return p.parse_args()


def main():
    args = parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Device:", device)
    set_seed(args.seed)

    r = args.data_root
    train_ds = UIEBDataset(os.path.join(r, "trainA"), os.path.join(r, "trainB"), args.img_size)
    val_ds = UIEBDataset(os.path.join(r, "valA"), os.path.join(r, "valB"), args.img_size)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.num_workers)
    val_loader = DataLoader(val_ds, batch_size=1, num_workers=args.num_workers)

    model = GeoMViTMambaUNet().to(device)
    criterion = TotalLoss().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, args.epochs)

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    best_psnr = 0.0

    for epoch in range(args.epochs):
        model.train()
        for x, y in tqdm(train_loader):
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            loss = criterion(model(x), y)
            loss.backward()
            optimizer.step()
        scheduler.step()

        model.eval()
        total = 0.0
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(device), y.to(device)
                total += psnr(model(x), y).item()
        avg = total / len(val_loader)
        print(f"Epoch {epoch + 1}/{args.epochs} | Val PSNR: {avg:.2f}")

        if avg > best_psnr:
            best_psnr = avg
            torch.save(model.state_dict(), args.out)

    print("Best PSNR:", best_psnr)


if __name__ == "__main__":
    main()
