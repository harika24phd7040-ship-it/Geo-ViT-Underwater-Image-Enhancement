import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models


class PerceptualLoss(nn.Module):
    """L1 distance between frozen VGG16 features (layers 0-15)."""

    def __init__(self):
        super().__init__()
        vgg = models.vgg16(weights=models.VGG16_Weights.IMAGENET1K_V1).features[:16]
        self.vgg = vgg.eval()
        for p in self.vgg.parameters():
            p.requires_grad = False

    def forward(self, x, y):
        return F.l1_loss(self.vgg(x), self.vgg(y))


def charbonnier(pred, gt):
    return torch.mean(torch.sqrt((pred - gt) ** 2 + 1e-6))


class TotalLoss(nn.Module):
    """Charbonnier + 0.1 * perceptual (as used in the training setup)."""

    def __init__(self, perc_weight=0.1):
        super().__init__()
        self.perceptual = PerceptualLoss()
        self.perc_weight = perc_weight

    def forward(self, pred, gt):
        return charbonnier(pred, gt) + self.perc_weight * self.perceptual(pred, gt)
