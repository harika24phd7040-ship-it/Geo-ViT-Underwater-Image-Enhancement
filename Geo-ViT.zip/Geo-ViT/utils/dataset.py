import os

import torchvision.transforms as T
from PIL import Image
from torch.utils.data import Dataset

IMG_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff")


class UIEBDataset(Dataset):
    """Paired (degraded, reference) underwater images. File names must match
    between `inp_dir` and `gt_dir`."""

    def __init__(self, inp_dir, gt_dir, img_size=256):
        self.images = sorted(f for f in os.listdir(inp_dir) if f.lower().endswith(IMG_EXTS))
        self.inp_dir = inp_dir
        self.gt_dir = gt_dir
        self.tf = T.Compose([T.Resize((img_size, img_size)), T.ToTensor()])

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        name = self.images[idx]
        inp = Image.open(os.path.join(self.inp_dir, name)).convert("RGB")
        gt = Image.open(os.path.join(self.gt_dir, name)).convert("RGB")
        return self.tf(inp), self.tf(gt)
