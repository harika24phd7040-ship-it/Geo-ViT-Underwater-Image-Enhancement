import torch
import torch.nn.functional as F


def psnr(pred, gt):
    """PSNR for images in [0, 1] (same formula as the original training code)."""
    mse = F.mse_loss(pred, gt)
    return 10 * torch.log10(1 / (mse + 1e-8))


def ssim_metric(pred, gt):
    """SSIM (requires `pytorch-msssim`)."""
    from pytorch_msssim import ssim
    return ssim(pred, gt, data_range=1.0, size_average=True)
