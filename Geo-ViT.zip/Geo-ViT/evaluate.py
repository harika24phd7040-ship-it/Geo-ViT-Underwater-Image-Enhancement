"""Evaluate a trained checkpoint (PSNR / SSIM) on a paired test folder.

Example:
    python evaluate.py --ckpt checkpoints/best_geomvitmamba_v2.pth \
        --input_dir /path/to/valA --gt_dir /path/to/valB
"""
import argparse

import torch
from torch.utils.data import DataLoader

from models import GeoMViTMambaUNet
from utils.dataset import UIEBDataset
from utils.metrics import psnr, ssim_metric


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--ckpt", required=True)
    p.add_argument("--input_dir", required=True)
    p.add_argument("--gt_dir", required=True)
    p.add_argument("--img_size", type=int, default=256)
    args = p.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = GeoMViTMambaUNet().to(device)
    model.load_state_dict(torch.load(args.ckpt, map_location=device))
    model.eval()

    loader = DataLoader(UIEBDataset(args.input_dir, args.gt_dir, args.img_size), batch_size=1)
    p_sum = s_sum = 0.0
    with torch.no_grad():
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            out = model(x)
            p_sum += psnr(out, y).item()
            s_sum += ssim_metric(out, y).item()
    n = len(loader)
    print(f"PSNR: {p_sum / n:.2f} dB | SSIM: {s_sum / n:.4f}")


if __name__ == "__main__":
    main()
